package com.luvcode.springcoredemo;

public interface Coach {

    String getDailyWorkout();

}
