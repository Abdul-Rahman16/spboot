package com.luvcode.springcoredemo.common;

public interface Coach {

    String getDailyWorkout();

}
